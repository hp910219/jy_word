# -*- coding: utf-8 -*-
# !/usr/bin/python
# Create Date 2018/6/4 0004
__author__ = 'huohuo'
from Word import Paragraph

if __name__ == "__main__":
    pass
    

def start():
    print 'import jy word successful'